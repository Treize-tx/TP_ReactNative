const HALL32_IMAGE = require("plan.png");

export const Hall32 = {
    address : "32 Rue du Clos Four, 63100 Clermont-Ferrand",
    image: HALL32_IMAGE
}